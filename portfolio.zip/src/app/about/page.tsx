export default function page() {
  return <div>page</div>;
}
